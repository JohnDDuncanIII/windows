taskbar.sam is an exported version of my config so it should just work after double clicking the file

for some reason it didn't import tasks.dll, which is the required plugin for the taskbar - if it forgot other plugins, just email me back

one serious note about tasks.dll: the reason i stopped using this config and started using bbLean's native taskbar is because tasks.dll is very shitty and buggy and clicking on a window in tasks.dll doesn't work that well (right clicking seems to switch to the window but also opens a menu, left clicking almost always does nothing)

i also added a slide in/out feature, but it's disabled last i checked, you can enable it again easily (if you can't figure out how just email me)